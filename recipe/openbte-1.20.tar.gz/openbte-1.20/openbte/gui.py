from openbte import Plot

def main():
  Plot(model='maps',repeat=[2,2,1])

 

