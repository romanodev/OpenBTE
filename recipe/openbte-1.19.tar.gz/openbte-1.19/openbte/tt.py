import sys
print(sys.kwargs)
