from openbte import Plot

def main():
  Plot(model='maps')

 

